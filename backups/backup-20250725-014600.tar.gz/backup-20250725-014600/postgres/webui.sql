--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg120+1)
-- Dumped by pg_dump version 16.9 (Debian 16.9-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cleanup_expired_webui_sessions(); Type: FUNCTION; Schema: public; Owner: mem0
--

CREATE FUNCTION public.cleanup_expired_webui_sessions() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM webui_user_sessions WHERE expires_at < CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.cleanup_expired_webui_sessions() OWNER TO mem0;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: webui_config; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.webui_config (
    id integer NOT NULL,
    config_key character varying(100) NOT NULL,
    config_value text,
    description text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webui_config OWNER TO mem0;

--
-- Name: TABLE webui_config; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.webui_config IS 'WebUI系统配置表';


--
-- Name: webui_config_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.webui_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webui_config_id_seq OWNER TO mem0;

--
-- Name: webui_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.webui_config_id_seq OWNED BY public.webui_config.id;


--
-- Name: webui_user_sessions; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.webui_user_sessions (
    id integer NOT NULL,
    session_id character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    user_info jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone NOT NULL,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.webui_user_sessions OWNER TO mem0;

--
-- Name: TABLE webui_user_sessions; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.webui_user_sessions IS 'WebUI用户会话表';


--
-- Name: webui_user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.webui_user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webui_user_sessions_id_seq OWNER TO mem0;

--
-- Name: webui_user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.webui_user_sessions_id_seq OWNED BY public.webui_user_sessions.id;


--
-- Name: webui_user_settings; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.webui_user_settings (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webui_user_settings OWNER TO mem0;

--
-- Name: TABLE webui_user_settings; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.webui_user_settings IS 'WebUI用户设置表';


--
-- Name: webui_user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.webui_user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webui_user_settings_id_seq OWNER TO mem0;

--
-- Name: webui_user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.webui_user_settings_id_seq OWNED BY public.webui_user_settings.id;


--
-- Name: webui_users; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.webui_users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    mem0_user_id character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.webui_users OWNER TO mem0;

--
-- Name: webui_users_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.webui_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webui_users_id_seq OWNER TO mem0;

--
-- Name: webui_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.webui_users_id_seq OWNED BY public.webui_users.id;


--
-- Name: webui_config id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_config ALTER COLUMN id SET DEFAULT nextval('public.webui_config_id_seq'::regclass);


--
-- Name: webui_user_sessions id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_sessions ALTER COLUMN id SET DEFAULT nextval('public.webui_user_sessions_id_seq'::regclass);


--
-- Name: webui_user_settings id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_settings ALTER COLUMN id SET DEFAULT nextval('public.webui_user_settings_id_seq'::regclass);


--
-- Name: webui_users id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_users ALTER COLUMN id SET DEFAULT nextval('public.webui_users_id_seq'::regclass);


--
-- Data for Name: webui_config; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.webui_config (id, config_key, config_value, description, updated_at) FROM stdin;
1	webui_version	2.0	WebUI版本号	2025-07-24 14:41:48.733916
2	database_initialized	true	WebUI数据库是否已初始化	2025-07-24 14:41:48.737878
\.


--
-- Data for Name: webui_user_sessions; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.webui_user_sessions (id, session_id, username, user_info, created_at, expires_at, last_activity, is_active) FROM stdin;
\.


--
-- Data for Name: webui_user_settings; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.webui_user_settings (id, username, setting_key, setting_value, updated_at) FROM stdin;
6	admin	ai_api_url	http://gemini-balance:8000	2025-07-24 14:41:48.729926
7	admin	ai_api_key	q1q2q3q4	2025-07-24 14:41:48.731907
1	admin	custom_instructions	请提取并结构化重要信息，保持清晰明了。	2025-07-24 14:48:00.080718
2	admin	include_content_types	["\\u6280\\u672f\\u6587\\u6863", "\\u4e2a\\u4eba\\u4fe1\\u606f"]	2025-07-24 14:48:00.112171
3	admin	exclude_content_types	[]	2025-07-24 14:48:00.131182
4	admin	max_results	10	2025-07-24 14:48:00.149396
5	admin	smart_reasoning	true	2025-07-24 14:48:00.167217
\.


--
-- Data for Name: webui_users; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.webui_users (id, username, password_hash, role, mem0_user_id, is_active, created_at, last_login, login_attempts, locked_until, metadata) FROM stdin;
1	admin	240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9	admin	admin_default	t	2025-07-24 14:42:29.206087	\N	0	\N	{}
\.


--
-- Name: webui_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.webui_config_id_seq', 2, true);


--
-- Name: webui_user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.webui_user_sessions_id_seq', 1, false);


--
-- Name: webui_user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.webui_user_settings_id_seq', 17, true);


--
-- Name: webui_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.webui_users_id_seq', 1, true);


--
-- Name: webui_config webui_config_config_key_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_config
    ADD CONSTRAINT webui_config_config_key_key UNIQUE (config_key);


--
-- Name: webui_config webui_config_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_config
    ADD CONSTRAINT webui_config_pkey PRIMARY KEY (id);


--
-- Name: webui_user_sessions webui_user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_sessions
    ADD CONSTRAINT webui_user_sessions_pkey PRIMARY KEY (id);


--
-- Name: webui_user_sessions webui_user_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_sessions
    ADD CONSTRAINT webui_user_sessions_session_id_key UNIQUE (session_id);


--
-- Name: webui_user_settings webui_user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_settings
    ADD CONSTRAINT webui_user_settings_pkey PRIMARY KEY (id);


--
-- Name: webui_user_settings webui_user_settings_username_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_user_settings
    ADD CONSTRAINT webui_user_settings_username_setting_key_key UNIQUE (username, setting_key);


--
-- Name: webui_users webui_users_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_users
    ADD CONSTRAINT webui_users_pkey PRIMARY KEY (id);


--
-- Name: webui_users webui_users_username_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.webui_users
    ADD CONSTRAINT webui_users_username_key UNIQUE (username);


--
-- Name: idx_webui_config_key; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_config_key ON public.webui_config USING btree (config_key);


--
-- Name: idx_webui_user_sessions_expires; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_user_sessions_expires ON public.webui_user_sessions USING btree (expires_at);


--
-- Name: idx_webui_user_sessions_session_id; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_user_sessions_session_id ON public.webui_user_sessions USING btree (session_id);


--
-- Name: idx_webui_user_sessions_username; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_user_sessions_username ON public.webui_user_sessions USING btree (username);


--
-- Name: idx_webui_user_settings_key; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_user_settings_key ON public.webui_user_settings USING btree (setting_key);


--
-- Name: idx_webui_user_settings_username; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_user_settings_username ON public.webui_user_settings USING btree (username);


--
-- Name: idx_webui_users_username; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_webui_users_username ON public.webui_users USING btree (username);


--
-- PostgreSQL database dump complete
--

