--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE mem0;
ALTER ROLE mem0 WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:UAcv5oO7vK4EhzCsD5TYww==$haKQWC24PR/mC7493l7kPWXSEJ3TN/KKRqyoi1WShy0=:qOQ/XH9oZm652P7RWPV8io6OLbWl+miW0BWFEc99rk0=';

--
-- User Configurations
--






--
-- PostgreSQL database cluster dump complete
--

