--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Debian 16.9-1.pgdg120+1)
-- Dumped by pg_dump version 16.9 (Debian 16.9-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: mem0
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM mem0_user_sessions WHERE expires_at < CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO mem0;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mem0_login_attempts; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.mem0_login_attempts (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    ip_address inet,
    user_agent text,
    success boolean NOT NULL,
    attempt_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    error_message text
);


ALTER TABLE public.mem0_login_attempts OWNER TO mem0;

--
-- Name: TABLE mem0_login_attempts; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.mem0_login_attempts IS 'Mem0系统登录尝试记录表';


--
-- Name: mem0_login_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.mem0_login_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mem0_login_attempts_id_seq OWNER TO mem0;

--
-- Name: mem0_login_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.mem0_login_attempts_id_seq OWNED BY public.mem0_login_attempts.id;


--
-- Name: mem0_user_sessions; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.mem0_user_sessions (
    id integer NOT NULL,
    user_id character varying(100) NOT NULL,
    session_token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address inet,
    user_agent text
);


ALTER TABLE public.mem0_user_sessions OWNER TO mem0;

--
-- Name: TABLE mem0_user_sessions; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.mem0_user_sessions IS 'Mem0系统用户会话表';


--
-- Name: mem0_user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.mem0_user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mem0_user_sessions_id_seq OWNER TO mem0;

--
-- Name: mem0_user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.mem0_user_sessions_id_seq OWNED BY public.mem0_user_sessions.id;


--
-- Name: mem0_user_settings; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.mem0_user_settings (
    id integer NOT NULL,
    user_id character varying(100) NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mem0_user_settings OWNER TO mem0;

--
-- Name: TABLE mem0_user_settings; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.mem0_user_settings IS 'Mem0系统用户设置表';


--
-- Name: mem0_user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.mem0_user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mem0_user_settings_id_seq OWNER TO mem0;

--
-- Name: mem0_user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.mem0_user_settings_id_seq OWNED BY public.mem0_user_settings.id;


--
-- Name: mem0_users; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.mem0_users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    user_id character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    password_changed_at timestamp without time zone,
    password_reset_at timestamp without time zone,
    password_reset_by character varying(50),
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.mem0_users OWNER TO mem0;

--
-- Name: TABLE mem0_users; Type: COMMENT; Schema: public; Owner: mem0
--

COMMENT ON TABLE public.mem0_users IS 'Mem0系统用户表';


--
-- Name: mem0_users_id_seq; Type: SEQUENCE; Schema: public; Owner: mem0
--

CREATE SEQUENCE public.mem0_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mem0_users_id_seq OWNER TO mem0;

--
-- Name: mem0_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mem0
--

ALTER SEQUENCE public.mem0_users_id_seq OWNED BY public.mem0_users.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: mem0
--

CREATE TABLE public.user_sessions (
    session_id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    user_info jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone NOT NULL,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.user_sessions OWNER TO mem0;

--
-- Name: mem0_login_attempts id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_login_attempts ALTER COLUMN id SET DEFAULT nextval('public.mem0_login_attempts_id_seq'::regclass);


--
-- Name: mem0_user_sessions id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_sessions ALTER COLUMN id SET DEFAULT nextval('public.mem0_user_sessions_id_seq'::regclass);


--
-- Name: mem0_user_settings id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_settings ALTER COLUMN id SET DEFAULT nextval('public.mem0_user_settings_id_seq'::regclass);


--
-- Name: mem0_users id; Type: DEFAULT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_users ALTER COLUMN id SET DEFAULT nextval('public.mem0_users_id_seq'::regclass);


--
-- Data for Name: mem0_login_attempts; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.mem0_login_attempts (id, username, ip_address, user_agent, success, attempt_time, error_message) FROM stdin;
\.


--
-- Data for Name: mem0_user_sessions; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.mem0_user_sessions (id, user_id, session_token, expires_at, created_at, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: mem0_user_settings; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.mem0_user_settings (id, user_id, setting_key, setting_value, updated_at) FROM stdin;
7	user_1753328095_5192	api_url	http://mem0-api:8000	2025-07-24 04:04:31.4337
8	user_1753328095_5192	api_key		2025-07-24 04:04:31.4337
1	admin_default	custom_instructions		2025-07-24 13:45:19.718853
2	admin_default	include_content_types	[""]	2025-07-24 13:45:19.718853
3	admin_default	exclude_content_types	[""]	2025-07-24 13:45:19.718853
4	admin_default	max_results	10	2025-07-24 13:45:19.718853
5	admin_default	smart_reasoning	true	2025-07-24 13:45:19.718853
6	admin_default	system_initialized	true	2025-07-24 13:45:19.718853
136	admin_default	ai_api_timeout	30	2025-07-24 12:09:15.684984
88	admin_default	show_model_info	true	2025-07-24 11:27:53.962257
9	admin_default	api_url	http://mem0-api:8000	2025-07-24 06:10:45.16031
10	admin_default	api_key	admin123	2025-07-24 06:10:45.16031
35	admin_default	ai_api_url	http://gemini-balance:8000	2025-07-25 06:37:13.980305
36	admin_default	ai_api_key	q1q2q3q4	2025-07-25 06:37:13.980305
47	admin_default	ai_api_last_update	1753425433	2025-07-25 06:37:13.980305
37	admin_default	ai_api_connected	true	2025-07-24 12:47:10.402005
38	admin_default	ai_api_last_test_time	1753361230	2025-07-24 12:47:10.402005
\.


--
-- Data for Name: mem0_users; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.mem0_users (id, username, user_id, password_hash, role, is_active, created_at, last_login, password_changed_at, password_reset_at, password_reset_by, login_attempts, locked_until, metadata) FROM stdin;
1	admin	admin_default	240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9	admin	t	2025-07-24 02:22:02.408217	2025-07-25 06:47:14.575552	\N	\N	\N	0	\N	{}
5	neo4j_test_user	user_1753430486_9689	ecd71870d1963316a97e3ac3408c9835ad8cf0f3c1bc703527c30265534f75ae	user	t	2025-07-25 08:01:26.846083	2025-07-25 08:02:04.924455	\N	\N	\N	0	\N	{}
2	testuser	user_1753328095_5192	eaaa4a79c43019473cc37be32ede6ea36c962bdf821fafbecc573c6931f63ea7	user	t	2025-07-24 03:34:55.240476	2025-07-24 04:00:22.791668	2025-07-24 03:58:40.705009	\N	\N	0	\N	{}
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: mem0
--

COPY public.user_sessions (session_id, user_id, username, user_info, created_at, expires_at, last_activity, is_active) FROM stdin;
cf6fb79b-76a3-453e-9c10-2beef0a16bf9	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T02:40:32.058243"}	2025-07-24 03:25:22.532615	2025-07-25 03:25:22.519276	2025-07-24 03:25:22.532615	f
1e7f7ec1-65b5-4794-97ee-0c98bc585214	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T03:43:58.204691"}	2025-07-24 03:50:04.973384	2025-07-25 03:50:04.959621	2025-07-24 03:50:04.973384	f
2d16db8f-4217-4349-848e-a6232ced713d	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T03:50:04.954032"}	2025-07-24 03:51:01.506342	2025-07-25 03:51:01.492629	2025-07-24 03:51:01.506342	f
d4779caa-ad8c-4094-b2a1-2f5a6fc57ff1	user_1753328095_5192	testuser	{"role": "user", "user_id": "user_1753328095_5192", "username": "testuser", "last_login": null}	2025-07-24 03:57:48.317213	2025-07-25 03:57:48.298523	2025-07-24 03:57:48.317213	f
637f9806-7102-4d6f-8c58-f863971c6f59	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T11:50:18.336702"}	2025-07-24 12:01:36.010202	2025-07-25 12:01:35.994686	2025-07-24 12:01:36.010202	t
4df92c10-baa0-4153-a3cb-2b99a52e5a89	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T06:53:20.215575"}	2025-07-24 11:07:50.769012	2025-07-25 11:07:50.75292	2025-07-24 11:09:07.060076	t
a685edd5-ff9b-4431-8a2f-35c5eff7caf1	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T16:16:28.639281"}	2025-07-24 16:22:57.823121	2025-07-25 16:22:57.808419	2025-07-24 16:22:57.823121	t
0279b6c9-e1b1-4e61-a193-f65fa7469f01	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T11:25:32.351241"}	2025-07-24 11:27:14.047549	2025-07-25 11:27:14.033795	2025-07-24 11:27:14.047549	t
f3a20fad-f6b7-478a-9a75-26163f70c638	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T15:30:50.177023"}	2025-07-24 15:53:30.019589	2025-07-25 15:53:30.005176	2025-07-24 15:53:30.019589	t
a1976848-c805-42a2-9d73-0f1041d1a336	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T16:22:57.796124"}	2025-07-24 16:26:18.821082	2025-07-25 16:26:18.806923	2025-07-24 16:26:18.821082	t
dea516bf-d7ce-4cca-95fc-292518ab2f82	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T12:55:18.871418"}	2025-07-24 14:47:14.567509	2025-07-25 14:47:14.55293	2025-07-24 14:47:14.567509	t
2cd64fbe-a903-450f-99b3-0d61f74a457b	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T16:29:02.767980"}	2025-07-24 17:05:49.719781	2025-07-25 17:05:49.704031	2025-07-24 17:05:49.719781	t
804325eb-94f5-4edc-bdcd-21be131bfc5d	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T04:31:29.214657"}	2025-07-24 04:51:17.282878	2025-07-25 04:51:17.266401	2025-07-24 05:57:39.551498	f
046d4477-5e73-4d94-8d83-b3f4ae9543d2	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T14:47:14.539909"}	2025-07-24 15:04:25.350571	2025-07-25 15:04:25.3345	2025-07-24 15:04:25.350571	t
35f5cbc5-900a-4b07-a21d-6cb743a2a57b	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T15:53:29.990144"}	2025-07-24 16:00:07.537008	2025-07-25 16:00:07.521096	2025-07-24 16:00:07.537008	t
8d8b815f-366c-40e9-aaf2-9a416bafde91	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T15:04:25.327907"}	2025-07-24 15:09:40.871605	2025-07-25 15:09:40.857274	2025-07-24 15:09:40.871605	t
5c7255df-a540-4103-96f7-4a8e225dc622	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T11:07:50.741498"}	2025-07-24 11:25:32.370848	2025-07-25 11:25:32.356891	2025-07-24 11:49:28.068135	t
69817d60-eedf-4f7f-8102-3ba4dd77da9e	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T11:50:04.653727"}	2025-07-24 11:50:18.356991	2025-07-25 11:50:18.342874	2025-07-24 11:50:18.356991	t
9bc7add9-31f5-4e2a-9cb3-b55f3c1b5049	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T12:08:55.690322"}	2025-07-24 12:11:14.739864	2025-07-25 12:11:14.727351	2025-07-24 12:46:43.367065	t
0b63284f-0668-4fec-8506-ae3e01199e88	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T12:11:14.715858"}	2025-07-24 12:55:18.894189	2025-07-25 12:55:18.878416	2025-07-24 14:03:38.098417	t
17eeb11c-7b31-46d7-b1b4-27b303588f6c	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T11:27:14.028761"}	2025-07-24 11:50:04.678097	2025-07-25 11:50:04.663382	2025-07-24 12:00:25.847076	t
88f797f1-1a30-402a-8a15-55aef96c7aa5	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T16:26:18.793303"}	2025-07-24 16:29:02.795801	2025-07-25 16:29:02.781374	2025-07-24 16:29:02.795801	t
8f4996cc-5315-4f94-b70d-e15b7bdd662f	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T16:00:07.512877"}	2025-07-24 16:16:28.66395	2025-07-25 16:16:28.648161	2025-07-24 16:16:28.66395	t
ca95fbd2-73bc-4a22-8a26-d18a595a854b	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T15:09:40.843828"}	2025-07-24 15:30:50.207435	2025-07-25 15:30:50.191573	2025-07-24 15:30:50.207435	t
63536872-9107-452f-ad22-ae9a0087165c	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T12:01:35.986983"}	2025-07-24 12:08:55.719082	2025-07-25 12:08:55.702626	2025-07-24 17:54:17.660076	t
1ec3df46-9538-410c-bb57-df7dd24dc34d	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T17:05:49.689755"}	2025-07-24 18:04:46.352009	2025-07-25 18:04:46.337166	2025-07-25 01:16:33.414691	t
9d863be2-9e4a-41c5-94a9-209c92304cc0	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": null}	2025-07-24 02:40:32.079819	2025-07-25 02:40:32.063971	2025-07-24 02:40:32.079819	f
f900046d-ea0d-4d77-9d5c-279fa547b249	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T03:25:22.513139"}	2025-07-24 03:43:58.227604	2025-07-25 03:43:58.213368	2025-07-24 03:43:58.227604	f
7529d089-93c3-4f71-bf35-fd48c87aa680	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T04:51:17.259531"}	2025-07-24 06:53:20.236869	2025-07-25 06:53:20.221609	2025-07-24 06:53:20.236869	f
cd8b6167-3740-4039-8f43-0663d2058ad4	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T18:04:46.329335"}	2025-07-25 02:00:50.222081	2025-07-26 02:00:50.20603	2025-07-25 02:01:14.999779	t
8aba1fea-1cab-4929-b03c-bde4ce7e0009	user_1753328095_5192	testuser	{"role": "user", "user_id": "user_1753328095_5192", "username": "testuser", "last_login": "2025-07-24T03:57:48.285772"}	2025-07-24 04:00:22.816307	2025-07-25 04:00:22.799727	2025-07-24 04:00:22.816307	f
36f114c4-ea97-4dd8-9415-588cf6c28000	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T04:05:41.629575"}	2025-07-24 04:30:35.579673	2025-07-25 04:30:35.565425	2025-07-24 04:30:35.579673	f
1634b4c0-8498-4016-b8fb-8104876e8cd0	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T04:30:35.560232"}	2025-07-24 04:31:29.234735	2025-07-25 04:31:29.220142	2025-07-24 04:31:29.234735	f
25e5b94e-7012-4449-a2e3-706e16dd81fc	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-24T03:51:01.479825"}	2025-07-24 04:05:41.659211	2025-07-25 04:05:41.643034	2025-07-24 07:28:35.754904	f
e34a2673-e57f-42fe-895d-ab94232ecc21	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T02:26:40.455729"}	2025-07-25 05:04:33.963051	2025-07-26 05:04:33.944743	2025-07-25 05:04:33.963051	t
66f30bce-1179-412c-a7d6-2d7ed4560d7c	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T05:04:33.934788"}	2025-07-25 05:10:09.58621	2025-07-26 05:10:09.5712	2025-07-25 05:10:09.58621	t
2cd4ea3e-988d-4ee6-bf03-7bea80d86af1	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T05:10:09.557831"}	2025-07-25 05:13:57.297599	2025-07-26 05:13:57.278566	2025-07-25 05:13:57.297599	t
02763db3-45ae-4066-b934-2c63bc0a201a	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T05:13:57.270934"}	2025-07-25 06:11:44.848256	2025-07-26 06:11:44.827364	2025-07-25 06:11:44.848256	t
1cda38bf-b0f2-4c62-96ff-19eaf7441f21	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T02:00:50.192604"}	2025-07-25 02:26:40.478508	2025-07-26 02:26:40.464514	2025-07-25 06:37:01.289729	f
e7281647-0bdb-4aa4-94d4-b4faef18793e	admin_default	admin	{"role": "admin", "user_id": "admin_default", "username": "admin", "last_login": "2025-07-25T06:11:44.814652"}	2025-07-25 06:37:08.094802	2025-07-26 06:37:08.079054	2025-07-25 07:50:14.977659	t
f1745e52-3eea-448c-b78b-6b46800ec11b	user_1753430486_9689	neo4j_test_user	{"role": "user", "user_id": "user_1753430486_9689", "username": "neo4j_test_user", "last_login": null}	2025-07-25 08:02:04.945351	2025-07-26 08:02:04.929674	2025-07-25 08:02:04.945351	t
\.


--
-- Name: mem0_login_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.mem0_login_attempts_id_seq', 1, false);


--
-- Name: mem0_user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.mem0_user_sessions_id_seq', 1, false);


--
-- Name: mem0_user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.mem0_user_settings_id_seq', 190, true);


--
-- Name: mem0_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mem0
--

SELECT pg_catalog.setval('public.mem0_users_id_seq', 5, true);


--
-- Name: mem0_login_attempts mem0_login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_login_attempts
    ADD CONSTRAINT mem0_login_attempts_pkey PRIMARY KEY (id);


--
-- Name: mem0_user_sessions mem0_user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_sessions
    ADD CONSTRAINT mem0_user_sessions_pkey PRIMARY KEY (id);


--
-- Name: mem0_user_sessions mem0_user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_sessions
    ADD CONSTRAINT mem0_user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: mem0_user_settings mem0_user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_settings
    ADD CONSTRAINT mem0_user_settings_pkey PRIMARY KEY (id);


--
-- Name: mem0_user_settings mem0_user_settings_user_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_settings
    ADD CONSTRAINT mem0_user_settings_user_id_setting_key_key UNIQUE (user_id, setting_key);


--
-- Name: mem0_users mem0_users_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_users
    ADD CONSTRAINT mem0_users_pkey PRIMARY KEY (id);


--
-- Name: mem0_users mem0_users_user_id_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_users
    ADD CONSTRAINT mem0_users_user_id_key UNIQUE (user_id);


--
-- Name: mem0_users mem0_users_username_key; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_users
    ADD CONSTRAINT mem0_users_username_key UNIQUE (username);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: idx_mem0_login_attempts_time; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_login_attempts_time ON public.mem0_login_attempts USING btree (attempt_time);


--
-- Name: idx_mem0_login_attempts_username; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_login_attempts_username ON public.mem0_login_attempts USING btree (username);


--
-- Name: idx_mem0_user_sessions_expires; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_user_sessions_expires ON public.mem0_user_sessions USING btree (expires_at);


--
-- Name: idx_mem0_user_sessions_token; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_user_sessions_token ON public.mem0_user_sessions USING btree (session_token);


--
-- Name: idx_mem0_user_sessions_user_id; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_user_sessions_user_id ON public.mem0_user_sessions USING btree (user_id);


--
-- Name: idx_mem0_user_settings_key; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_user_settings_key ON public.mem0_user_settings USING btree (setting_key);


--
-- Name: idx_mem0_user_settings_user_id; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_user_settings_user_id ON public.mem0_user_settings USING btree (user_id);


--
-- Name: idx_mem0_users_active; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_users_active ON public.mem0_users USING btree (is_active);


--
-- Name: idx_mem0_users_role; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_users_role ON public.mem0_users USING btree (role);


--
-- Name: idx_mem0_users_user_id; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_users_user_id ON public.mem0_users USING btree (user_id);


--
-- Name: idx_mem0_users_username; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_mem0_users_username ON public.mem0_users USING btree (username);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_user_id; Type: INDEX; Schema: public; Owner: mem0
--

CREATE INDEX idx_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: mem0_user_sessions mem0_user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_sessions
    ADD CONSTRAINT mem0_user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.mem0_users(user_id) ON DELETE CASCADE;


--
-- Name: mem0_user_settings mem0_user_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mem0
--

ALTER TABLE ONLY public.mem0_user_settings
    ADD CONSTRAINT mem0_user_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.mem0_users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

